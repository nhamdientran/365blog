<h2><?= $title ?></h2>
<p>This is Tran Nham project for PHP course.</p>